ALTER TABLE teams
DROP
COLUMN logo_url;